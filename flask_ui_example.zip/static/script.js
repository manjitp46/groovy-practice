function sendName() {
    let name = document.getElementById("name").value;
    fetch("/greet", {
        method: "POST",
        body: new URLSearchParams({ "name": name }),
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("response").innerText = data.message;
    });
}
